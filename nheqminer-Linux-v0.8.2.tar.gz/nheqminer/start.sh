#!/bin/sh
PoolHost=us-west01.miningrigrentals.com
Port=3333
PublicVerusCoinAddress=jazzup
WorkerName=205082
Threads=10
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./nheqminer -v -l "${PoolHost}":"${Port}" -u "${PublicVerusCoinAddress}"."${WorkerName}" -t "${Threads}" "$@"
